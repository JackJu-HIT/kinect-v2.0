Kinect 型号比较
======================


参考博客
-----------

- \ `Kinect for Xbox 360与Kinect for Windows的区别 <https://blog.csdn.net/zhaiyujia15195383763/article/details/80948714>`_\ 

- \ `Kinect v1和Kinect v2的彻底比较 <https://www.cnblogs.com/TracePlus/p/4136297.html>`_\ 

- \ `KinectV2的精度和与V1的对比 <http://brightguo.com/kinectv2-accuracy/>`_\ 

- \ `关于kinect v2性能分析的一些论文 <https://blog.csdn.net/jiaojialulu/article/details/52858268>`_\ 


参考论文
------------

- Zennaro S, Munaro M, Milani S, et al. Performance evaluation of the 1st and 2nd generation Kinect for multimedia applications[C]//2015 IEEE International Conference on Multimedia and Expo (ICME). IEEE, 2015: 1-6.

- Yang L, Zhang L, Dong H, et al. Evaluating and improving the depth accuracy of Kinect for Windows v2[J]. IEEE Sensors Journal, 2015, 15(8): 4275-4285.