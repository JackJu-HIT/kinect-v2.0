Kinect 开发文档
===================


Kinect v1 开发文档
-----------------------

目前微软官网已彻底删除了 Kinect for Windows SDK v1 的文档资料。替代办法是通过网页快照存档网站 Wayback Machine 来查阅\ `官方文档的历史快照 <https://web.archive.org/web/20130906183129/http://msdn.microsoft.com/en-us/library/hh855347.aspx>`_\ 。

几个时间节点：

- 微软官网最后发布的一代 Kinect SDK 版本号为 1.8.0.595，发布日期为 2013 年 9 月 13 日，在此之后文档更新应基本停止。
- 2014 年 10 月微软发布第二代 Kinect for Windows。
- 微软官网大约在 17 年至 18 年前后彻底撤掉了 Kinect SDK v1 文档的存档，网页快照不再记录。

另外，网页快照的抓取时间是有一定随机性的，有时一些页面可以查看，但另一些页面可能会报错，对于报错的情况，可以换一个时间节点查看。


Kinect v2 开发文档
----------------------

\ `微软官方文档存档 <https://docs.microsoft.com/en-us/previous-versions/windows/kinect/dn799271(v=ieb.10)>`_\ 