#pragma once
#include <SDL_opengl.h>
#include <SDL.h>

bool init(int argc, char* argv[]);
void execute();