#pragma once
const int width = 512;
const int height = 424;
const int colorwidth = 1920;
const int colorheight = 1080;

void drawKinectData();
